# Unit Testing for Prototype 1
# @author KHZMAS001 MDZGUM002

from prototype1 import *
import prototype1
import unittest
import os
    
class TestPrototype1(unittest.TestCase):
    def setUp(self):
        pass

    def test_1_Input_txt(self):
        line = os.system("python3 prototype1.py pop.txt 1")
        self.assertRaises(TypeError)

    def test_2_input_invNo(self):
        line = os.system("python3 prototype1.py k.wcard 8")
        self.assertRaises(ValueError)
    
    def test_3_input_notEnoughArguments(self):
        line = os.system("python3 prototype1.py k.wcard")
        self.assertRaises(SyntaxError)

    def test_4_Genetic_Algorithm_txt(self):
        self.assertRaises((TypeError,ValueError), prototype1.geneticAlgorithm,"a.txt", "3")

    def test_5_Genetic_Algorithm_invNo(self):
        self.assertRaises(TypeError, prototype1.geneticAlgorithm, "test1.wcard", 1)

    #def test_5_Genetic_Algorithm_Correctrun(self):
    #    self.assertEqual(prototype1.geneticAlgorithm("test1.wcard", "2"), 0)
    
    def test_6_callCarlSat_invTestFile(self):
        arr = ["1","1","1","1","1","1","1","3"]
        self.assertRaises((TypeError,ValueError), prototype1.callCarlSat, "test1.txt", arr, "1")

    def test_7_callCarlSat_invArray(self):
        arr = [1,1,1,1,1,1,1,3]
        self.assertRaises((TypeError,ValueError), prototype1.callCarlSat, "test1.wcard", arr, "2")

    def test_8_removeElements_invArrayType(self):
        arr = [1,2,3,4]
        self.assertRaises((TypeError), prototype1.removeElements, arr)

    def tearDown(self) -> None:
        return super().tearDown()

        
    
if __name__ == '__main__':
    unittest.main
