#Import modules for elementwize problem
#from _typeshed import Self
from typing import ValuesView
import numpy as np
import autograd.numpy as anp
from pymoo.util.misc import stack
from pymoo.model.problem import Problem

#Import modules for DE
from pymoo.algorithms.so_de import DE
from pymoo.operators.sampling.latin_hypercube_sampling import LatinHypercubeSampling
from pymoo.optimize import minimize
from pymoo.factory import get_termination

#Import for arguments passed to system
import sys

#Import for CarlSAT
import os
import subprocess

#import for Paralellization
import multiprocessing

# pool is a global variable, that will not change during run
n_threads = multiprocessing.cpu_count()
pool = multiprocessing.pool.ThreadPool(n_threads)


#Define elementwise problem
class MyProblem(Problem):
    def __init__(self, *args, **kwargs):

        #19 values the problem will choose (0-18) for each parameter
        self.const_a = [1,2,3,5,10,20,30,50,75,100,200,300,400,500,600,700,800,900,1000]
        self.const_b = [1,2,3,5,10,20,30,50,75,100,200,300,400,500,600,700,800,900,1000]
        self.const_c = [10,20,30,40,50,75,100,250,500,1000,2500,5000,10000,25000,50000,100000,250000,500000,1000000]                   
        self.const_e = [0.1,0.2,0.3,0.4,0.5,1,2,3,4,5,8,10,20,50,100,250,500,750,1000]      
        self.const_f = [0.1,0.2,0.3,0.4,0.5,1,2,3,4,5,8,10,20,50,100,250,500,750,1000]                     
        self.const_r = [1,2,3,5,10,50,100,500,1000,5000,10000,50000,100000,500000,1000000,5000000,10000000,50000000,100000000] 
        self.const_x = [1,2,3,5,10,20,30,40,50,75,100,250,500,750,1000,2500,5000,7500,10000]              
        
        # Obtain the args (filename and timeout) passed from the GA 
        self.initVar = args

        super().__init__(n_var=7,  
                         n_obj=2,
                         n_constr=0,
                         #              a     b     c     e     f     r     x    # we're picking from a list
                         xl = np.array([ 0,    0,    0,    0,    0,    0,    0]), # lower bounds of vars
                         xu = np.array([18,   18,   18,   18,   18,   18,   18]), # upper bounds of vars
                         elementwise_evaluation=True, **kwargs
                         )


    def _evaluate(self, x, out , *args, **kwaargs):  #x is the list of parameters supplied by the GA algorithm (in this case DE)
        
        # Variables are chosen by the GA, and changed accordingly per trial
        a = self.const_a[round(x[0])]
        b = self.const_b[round(x[1])]
        c = self.const_c[round(x[2])]
        e = self.const_e[round(x[3])]
        f = self.const_f[round(x[4])]
        r = self.const_r[round(x[5])]
        topx = self.const_x[round(x[6])]
        v = 3 

        # Obtain file name and timeout from the initialization of the function
        filetime = self.initVar[0]
        
        # Make an array of type int using the variables provided
        arr = [a,b,c,e,f,r,topx,v]
        arr = list(map(str, arr))
        # Displays the current parameters being passed to CarlSAT
        # print(arr)

        out["F"] = callCarlSat(filetime[0], arr, filetime[1])


#Call Solver
def callCarlSat(filename, arrParms, timeout):
    pathFilename = os.getcwd() + filename
    if (filename.find(".wcard") == -1):
        raise TypeError("Filename is incorrect")
    #elif (os.path.isFile(pathFilename)):
    #    raise FileNotFoundError("File does not exist in current working directory\nPlease put [wcard] file in the same directory as program")
    elif (type(arrParms[0]) != str):
        raise TypeError("Array is not string. \nPlease input a String array")
    elif (timeout != "1" and timeout != "2" and timeout != "10"):
        raise ValueError("Please input a timeout of 1, 2 or 10, as per program requirements")
    a = arrParms[0] #"2"
    b = arrParms[1] #"4"
    c = arrParms[2] 
    e = arrParms[3] 
    f = arrParms[4] 
    r = arrParms[5] 
    x = arrParms[6] 
    t = timeout
    v = arrParms[7] # should always be "3"
    z = filename
    process = subprocess.run([os.path.join(os.getcwd(), 'CarlSAT'), '-a', a, '-b', b, '-c', c, '-e', e, '-f', f, '-r', r, '-x', x, '-t', t, '-v', v, '-z', z], cwd = os.getcwd(),
    capture_output=True).stdout

    #conversion of bytes to string
    data = process.decode()
    

    #string slicing to get last 2 lines of CarlSAT output
    data = data[data.find('o '):-1]

    #converting cost to int
    strCost = data[data.find('\no ')+2:data.find('\n')]
    cost = int(strCost.replace(',',''), base=10)

    #converting time to float
    time = float(data[data.find('Time: ')+6:data.find('s')-1])

    objective = cost + time
    obj = [cost, time]
    return objective


# Genetic algorithm
def geneticAlgorithm(filename, timeout):

    # Test whether filename and timeout is valid
    if (filename.find(".wcard") == -1):
        raise TypeError("Filename is incorrect")
    
    if (timeout != "1" and timeout != "2" and timeout != "10"):                     # If the timeout is not "1","2" or "10", send an error with the correct syntax
        raise ValueError("Timeout must be either 1, 2 or 10")

    # Initialize problem
    initVar = [filename, timeout]
    problem = MyProblem(initVar, parallelization = ('starmap', pool.starmap))         # Problem assignment, with parallelization using the starmap 

    termination = get_termination("n_gen", 50)                               # After 32 Generations, stop the pymoo

    # Initialize algorithm
    algorithm = DE (
        pop_size= 20,                                                        # 32 this is the number of items that are sampled per generation. Each generation, the best go though, and are used to construct new offspring.
        sampling=LatinHypercubeSampling(iterations=100, criterion="maxmin"), # Defines the initial set of solutions which are the starting point of the optimization
        variant="DE/rand/1/bin",                                             # The different variants of DE to be used.
        CR=0.5,                                                              # Probability the individual exchanges variable values from the donor vector
        F=0.3,                                                               # Crossover weight
        dither="vector",                                                     # Different individual used one for each individual
        jitter=False                                                         # Strategy for adaptive weights (F). A very small value is added or subtracted to the weight used for the crossover for each individual
    )


    #Optimize with minimize
    res = minimize(problem,                                                  # The problem defined above
                algorithm,                                                   # The algorithm provided by pymoo
                termination,                                                 # Tells the program when it needs to stop running
                seed = 1,                                                    # Tells the 
                save_history = True,                                         # For diagnostics
                verbose = True                                              # Shows the programs processing if set to 'True'
    )
    return res.X

def removeElements(arr1):
    if (type(arr1[0]) == str):  
        while (True):
            if (arr1.count(".") > 0):
                if (arr1[arr1.index(".")+1]=="0"):
                    arr1.remove("0")
                arr1.remove(".")
            if (arr1.count(",")> 0):
                arr1.remove(",")
            if (arr1.count(" ") > 0):
                arr1.remove(" ")
            else:
                break
        if (arr1.count("[") > 0):
            arr1.remove("[")
        if (arr1.count("]") > 0):
            arr1.remove("]")
    else:
        raise TypeError("Correct type is str")
    
    return arr1

#main function
if __name__ == '__main__':

    n = len(sys.argv)
    if (n == 3):

    # Prompt user for filename and timeout
        filename = sys.argv[1]                                                              # Gets the filename from the second argument passed in the console
        timeout = sys.argv[2]                                                               # Gets the timeout from the third argument passed in the console

        if (filename.find(".wcard") == -1):                                                 # If the filename does not contain .wcard, send an error with the correct syntax
            raise TypeError("Correct syntax is \'python3 prototype1 [wcard] [timeout]\'")
        #elif 
        if (timeout != "1" and timeout != "2" and timeout != "10"):                           # If the timeout is not "1","2" or "10", send an error with the correct syntax
            raise ValueError("Timeout must be either 1, 2 or 10")

        print("Starting HyperOptimizer....")
        output = geneticAlgorithm(filename, timeout)
        output = output.round()
        arr = output.tolist()

        arr = list(map(str,arr))
        arr1 = list(map(str, arr[0]))
        arr1 = removeElements(arr1)
        arr1.append("3")

        print("\nBest objective parameters =", (arr1))
        #print("Corresponding to a score of %s" %(callCarlSat(filename, arr1, timeout)))
    else:
        raise SyntaxError("Correct syntax to start is \'python3 prototype1 [wcard] [timeout]\'")